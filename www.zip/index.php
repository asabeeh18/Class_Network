
<html>
<head>
<title> start </title></head>
<body>
<form method="post" action=logini.php>
Username<input type='text' name='name' placeholder='Roll Number' required='required'><br>
Password<input type='password' name='password' required='required'><br>

<input type="submit">
</body>
</html>