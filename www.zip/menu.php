<?php 
require_once 'login.php';
	$connection=new mysqli($db_hostname,$db_username,$db_password,$db_database);
	if($connection->connect_error)
		echo "COnnect Error:".$db_database."<br>";
?>
<html>
	<head><title>HOME</title></head>
	<body>
	<ul>
		<li><h1><?php if(isset($_COOKIE['username'])) $roll=$_COOKIE['username']; else die("BYE"); 
		if(isset($roll)) echo $roll; else die("HAGA NA!"); ?></h1>
		<?php
		$str="select `dp` from `user` where '$roll'=`roll_no`";
		$result=$connection->query($str);
		if($result)
		{
			$pic=$result->fetch_row();
			//echo $pic[0];
			echo "<img src=$pic[0] alt='some_text'>"."<br>";
		}
		else echo "hAGA NA!";
		?>
		<li><a href="Profile.html">My Profile</a></li>
		<li><a href="ref.html">References</a></li>
		<li><a href="events.html">Events</a></li>
		<li><a href="discl.html">Discussions</a></li>
		<li><a href="logout.php">Logout</a></li>
	</body>
</html>