<html>
	<head><title>User Profile</title></head>
	<body>
<?php

		$name="YO";	
	echo <<<EOT
<table>
<tr>
<td>NAME</td>
<td>$name</td>
</tr>
<tr>
<td>Rollno.</td>
<td>$roll</td>
</tr>
<tr>
<td>pointer</td>
<td>$name</td>
</tr>
</table>
EOT;
?>

	</body>
</html>