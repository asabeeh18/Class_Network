<?php
$db_hostname='localhost';
$db_database='project_test';
$db_username='root';
$db_password='';
?>